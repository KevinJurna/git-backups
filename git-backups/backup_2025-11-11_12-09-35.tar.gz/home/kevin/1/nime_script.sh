read -p "Mis on sinu nimi?: " nimi
echo "Nimi: $nimi" >> nimed.txt
 
