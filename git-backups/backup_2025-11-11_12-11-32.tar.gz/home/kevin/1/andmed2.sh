read -p "Sisesta oma nimi: " nimi
read -p "Sisesta oma vanus: " vanus
kuupaev=$(date "+%Y-%m-%d %H:%M:%S")

echo "Nimi: $nimi, Vanus: $vanus, Sisestamise_aeg: $kuupaev" >> kõik_kasutajad.txt

if [[  "$nimi" == "root" || "$nimi" == "admin"  ]]; then
        echo "Nimi: $nimi, Vanus: $vanus, Sisestamise_aeg: $kuupaev" >> admin_info.txt
elif [[ "$vanus" -lt 25 ]]; then
	echo "Nimi: $nimi, Vanus: $vanus, Sisestamise_aeg; $kuupaev" >> vanemad.txt

fi



