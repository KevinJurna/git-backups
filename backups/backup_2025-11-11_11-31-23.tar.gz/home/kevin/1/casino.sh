number=$(( RANDOM % 10 + 1))
read -p "Arva number 1-10: " guess
if [[  "$guess" -eq "$number"  ]]; then
	echo "Õige"
else
	echo "Vale, number oli $number"
fi
