echo "Siin on nali:"
curl -s https://icanhazdadjoke.com/ -H "Accept: text/plain"
