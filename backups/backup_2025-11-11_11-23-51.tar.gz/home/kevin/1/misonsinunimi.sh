read -p "Mis on sinu nimi? " nimi
echo "Tere $nimi"
