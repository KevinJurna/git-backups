read -p "Mis on sinu nimi?: " nimi
read -p "Mis on sinu vanus?: " vanus
read -p "Mis on sinu elukoht?: " elukoht
kuupaev=$(date "+%Y-%m-%d %H:%M:%S")

echo "Nimi: $nimi, Vanus: $vanus, Elukoht: $elukoht, Sisestamise_aeg: $kuupaev" >> kontaktandmed.txt

if [[  "$nimi" -eq "root"  ]]; then
	echo "Nimi: $nimi, Vanus: $vanus, Elukoht: $elukoht, Sisestamise_aeg: $kuupaev" >> admin_login.txt
fi
