print("Tere ma olen kevin")
palk = 1000
if palk == 1000:
	print("Palk on tuhat")
else:
	print("Palk ei ole tuhat")
